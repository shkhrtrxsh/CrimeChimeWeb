import React, { useEffect } from 'react';
import * as Yup from 'yup';
import "yup-phone";
import { useState } from 'react';
import { useNavigate, Link as RouterLink } from 'react-router-dom';
// form
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { SaveButton } from 'src/components/Button'

import { useSelector, useDispatch } from 'react-redux';
import { getMyReport } from 'src/store/api/report';
import { alpha, styled, useTheme } from '@mui/material/styles';
import { Paper, Button, Box, Container, Stack, Grid } from '@mui/material'
import UserSideName from './components/UserSideNav';
import Page from '../../../components/Page';
import { FormProvider, RHFTextField, RHFCheckbox } from '../../../components/hook-form';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';

const PaperStyle = styled(Paper)(({ theme }) => ({

}));

const MyReport = () => {

    const dispatch = useDispatch();
    const navigate = useNavigate();
    const theme = useTheme();

    const { reports } = useSelector((state) => ({ ...state.report }));

    useEffect(() => {
        dispatch(getMyReport({}))

        console.log(reports)
    }, [])



    return (
        <Page>
            <Container sx={{
                marginTop: '20px'
            }}>
                <Grid container spacing={3}>
                    <UserSideName />
                    <Grid item md={9} xs={12}>
                        <Grid container spacing={3}>
                            {reports && reports.map((report, index) => (
                                <Grid item md={6} xs={12} key={index}>
                                    <Card>
                                        <CardMedia
                                            component="img"
                                            alt="green iguana"
                                            image={report.report_image && process.env.REACT_APP_API_URL + '/' + report.report_image.path}
                                        />
                                        <CardContent>
                                            <Typography gutterBottom variant="h5" component="div">
                                                {report.location}
                                            </Typography>
                                            <Typography variant="body1" color="text.primary">
                                                <img style={{
                                                    width: '45px',
                                                    paddingRight: '8px',
                                                    paddingTop: '4px',
                                                    float: 'left'
                                                }}
                                                    src={process.env.REACT_APP_API_URL + '/' + report.crime.icon} />

                                                {report.crime.name}
                                            </Typography>
                                            <Typography variant="body2" color="text.primary">
                                                {report.specific_crime.name}
                                            </Typography>
                                            <Typography variant="body2" color="text.secondary" sx={{ marginTop: '15px' }}>
                                                {report.description}
                                            </Typography>
                                        </CardContent>
                                        <CardActions sx={{    paddingLeft: '24px'}}>
                                            <Button onClick={() => {navigate('/report?id='+report.id)}} size="small">view Report</Button>
                                        </CardActions>
                                    </Card>
                                </Grid>
                            ))}
                        </Grid>
                    </Grid>
                </Grid>
            </Container>
        </Page>
    );
}

export default MyReport
