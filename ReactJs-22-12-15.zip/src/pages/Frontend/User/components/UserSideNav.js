import * as React from 'react';
import Divider from '@mui/material/Divider';
import { Link } from 'react-router-dom';
import Paper from '@mui/material/Paper';
import MenuList from '@mui/material/MenuList';
import MenuItem from '@mui/material/MenuItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemIcon from '@mui/material/ListItemIcon';
import Typography from '@mui/material/Typography';
import ContentCut from '@mui/icons-material/ContentCut';
import PersonIcon from '@mui/icons-material/Person';
import ManageAccountsIcon from '@mui/icons-material/ManageAccounts';
import ContentCopy from '@mui/icons-material/ContentCopy';
import ContentPaste from '@mui/icons-material/ContentPaste';
import Grid from '@mui/material/Grid';
import Cloud from '@mui/icons-material/Cloud';
import { alpha, styled, useTheme } from '@mui/material/styles';

export default function UserSideName() {
  const theme = useTheme()
  return (
    <Grid item md={3} sx={{
      background: "#000",
      [theme.breakpoints.down('md')]: {
        display: 'none'
      }
    }}>
      <Paper sx={{ maxWidth: '100%', backgroundColor: theme.palette.primary.main }}>
        <MenuList>
          <MenuItem component={Link} to="/profile">
            <ListItemIcon sx={{ color: theme.palette.secondary.main }}>
              <PersonIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText sx={{ color: theme.palette.secondary.main }}>User Profile</ListItemText>
          </MenuItem>
          <MenuItem component={Link} to="/profile/my-report">
            <ListItemIcon sx={{ color: theme.palette.secondary.main }}>
              <ManageAccountsIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText sx={{ color: theme.palette.secondary.main }}>My Reports</ListItemText>
          </MenuItem>
        </MenuList>
      </Paper>
    </Grid>
  );
}