import React, { useEffect, useState } from 'react';
import {
    Drawer,
    Button,
    Paper,
    Stack,
    InputLabel,
    Select,
    MenuItem,
    ListItemIcon,
    FormControl,
    ListItemText,
    Typography,
    Box,
    Fab,
} from '@mui/material';
import GoogleAutoComplete from 'src/components/GoogleMap/GoogleAutoComplete';
import { alpha, styled, useTheme } from '@mui/material/styles';
import { useSelector, useDispatch } from 'react-redux';
import { addReport, getCrimes, getSpecificCrimesById } from 'src/store/api/report';
import { SaveButton } from 'src/components/Button';
import MenuIcon from '@mui/icons-material/Menu';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { DRAWER_WIDTH, APPBAR_MOBILE, APPBAR_DESKTOP } from 'src/constants/theme'
import AddIcon from '@mui/icons-material/Add';

const OuterPaperStyle = styled(Paper)(({ theme }) => ({
    width: '500px',
    paddingLeft: '30px',
    paddingRight: '30px',
    paddingTop: '60px'
}));

const ImageIcon = styled('img')(({ theme }) => ({
    width: '25px'
}));

const CrimeFormControl = styled(FormControl)(({ theme }) => ({
    '& .MuiSelect-select.MuiSelect-outlined': {
        // padding: '10.5px 14px'
    },
    '& .MuiSelect-select.MuiSelect-outlined .MuiListItemIcon-root': {
        float: 'left',
        minWidth: '40px',
        marginTop: '5px'
    }
}));

const BoxButtonStyle = styled(Box)(({ theme }) => ({
    position: 'absolute',
    right: '15px',
    top: APPBAR_DESKTOP + 15 + 'px',
    '& .MuiButtonBase-root.MuiFab-root': {
        marginRight: '10px'
    }
}));

export default function DetailReport() {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const theme = useTheme();
    const [state, setState] = React.useState(true);

    const toggleDrawer = (event) => {
        setState(event);
    };

    return (
        <React.Fragment>
            <Drawer
                anchor="left"
                open={state}
                onClose={() => toggleDrawer(false)}
            >
                <OuterPaperStyle>
                    <Stack spacing={3}>
                        <Typography variant="h4" component="h4" sx={{
                            marginBottom:"20px"
                        }}>
                            Filter your report
                        </Typography>
                    </Stack>
                </OuterPaperStyle>

            </Drawer>
        </React.Fragment>
    );
}