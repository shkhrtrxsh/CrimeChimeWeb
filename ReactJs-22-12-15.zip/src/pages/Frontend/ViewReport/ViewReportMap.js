import React, { useState, useEffect, useRef } from 'react';
import { GoogleMap, Marker } from '@react-google-maps/api';
import { alpha, styled, useTheme } from '@mui/material/styles';
import {
    Stack,
    Container,
    Typography,
    Card,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    ListItemIcon,
    ListItemText,
    Drawer,
    Paper
} from '@mui/material';
import { useNavigate, Link as RouterLink, useSearchParams } from 'react-router-dom';
// form
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';

import { useSelector, useDispatch } from 'react-redux';
import { getReportByArea } from 'src/store/api/report';
import * as Yup from 'yup';
import "yup-phone";
import { CurrentLocationCoordinates } from 'src/helpers/LocationHelper';

import { FormProvider, RHFTextField, RHFCheckbox } from '../../../components/hook-form';
import { SaveButton } from 'src/components/Button';
import { DRAWER_WIDTH, APPBAR_MOBILE, APPBAR_DESKTOP } from 'src/constants/theme'
import UploadImage from 'src/components/UploadImage';
import GoogleAutoComplete from 'src/components/GoogleMap/GoogleAutoComplete';
import SearchFilter from './SearchFilter';
import { positionLatitude, positionLongitude, mapSettings } from 'src/helpers/LocationHelper';
import { Box } from '@mui/system';



const containerStyle = {
    width: '100%',
    height: `calc(100vh - ${APPBAR_DESKTOP}px)`
};

const PaperStyle = styled(Card)(({ theme }) => ({
    // padding:'.5rem',
    boxShadow: `${theme.shadows[3]} !important`,
    borderRadius: Number(theme.shape.borderRadius),
    '& .MuiPaper-root.MuiPaper-elevation': {
        boxShadow: 'none'
    }
}));

const OuterPaperStyle = styled(Paper)(({ theme }) => ({
    [theme.breakpoints.up('sm')]: {
        width: '500px',
    },
    paddingLeft: '30px',
    paddingRight: '30px',
    paddingTop: '60px'
}));

const ImageIcon = styled('img')(({ theme }) => ({
    width: '25px'
}));

const CrimeFormControl = styled(FormControl)(({ theme }) => ({
    '& .MuiSelect-select.MuiSelect-outlined': {
        // padding: '10.5px 14px'
    },
    '& .MuiSelect-select.MuiSelect-outlined .MuiListItemIcon-root': {
        float: 'left',
        minWidth: '40px',
        marginTop: '5px'
    }
}));

const ContentStyle = styled('div')(({ theme }) => ({
    width: 480,
    margin: 'auto',
    display: 'flex',
    justifyContent: 'center',
    flexDirection: 'column',
}));

const ImageList = styled('img')(({ theme }) => ({
    width:'47%',
    margin: '1% 1.5%',
    display: 'inline-block',
    boxShadow: `${theme.shadows[3]} !important`,
    borderRadius: Number(theme.shape.borderRadius),
}));

const HeaderStyle = styled('div')(({ theme }) => ({
    margin: '2rem 2rem .6rem 2rem'
}));


const ViewReportMap = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const theme = useTheme();
    const [detailToggleState, setDetailToggleState] = useState(false);
    const [reportDetail, setReportDetail] = useState(null);

    const detailToggleDrawer = (event) => {
        setDetailToggleState(event);
    };

    const position = CurrentLocationCoordinates()

    const { reports } = useSelector((state) => ({ ...state.report }));

    useEffect(() => {
        let query = '';
        if (searchParams.get('id')) {
            query += `id=${searchParams.get('id')}`
        } else {
            if (searchParams.get('location') !== null) {
                query += `location=${searchParams.get('location')}&`
            }
            if (searchParams.get('latitude') !== null) {
                query += `latitude=${searchParams.get('latitude')}&`
            }
            if (searchParams.get('longitude') !== null) {
                query += `longitude=${searchParams.get('longitude')}&`
            }
            if (searchParams.get('crime') !== null) {
                query += `crime=${searchParams.get('crime')}&`
            }
            if (searchParams.get('specific-crime') !== null) {
                query += `specific-crime=${searchParams.get('specific-crime')}`
            }
        }
        dispatch(getReportByArea({ query }))
        console.log('view report map')
    }, [searchParams])

    const reportDetails = (report) => {
        setReportDetail(report)
        console.log(report)
        setDetailToggleState(true)
    }


    return (
        <>
            <Drawer
                anchor="left"
                open={detailToggleState}
                onClose={() => detailToggleDrawer(false)}
                sx={{ "& .MuiDrawer-paper" : {
                    
                    [theme.breakpoints.down('md')]: {
                        width:'85%',
                    },
                }}}
            >
                <OuterPaperStyle>
                    <Stack spacing={3}>
                        <Typography variant="h5" component="h5">
                            {reportDetail && reportDetail.location}
                        </Typography>
                        <Box>
                            <img style={{
                                width: '50px',
                                paddingRight: '8px',
                                paddingTop: '4px',
                                float: 'left'
                            }}
                                src={reportDetail && process.env.REACT_APP_API_URL + '/' + reportDetail.crime.icon} />
                            <Typography variant="h6" component="h6">
                                {reportDetail && reportDetail.crime.name}
                            </Typography>
                            <Typography variant="body2" color="text.primary">
                                {reportDetail && reportDetail.specific_crime.name}
                            </Typography>
                        </Box>
                        <Typography variant="body2" color="text.secondary" sx={{ marginTop: '15px' }}>
                            {reportDetail && reportDetail.description}
                        </Typography>
                        <Box>
                            {reportDetail && reportDetail.report_images.map((image, index) => (
                                <ImageList src={reportDetail && process.env.REACT_APP_API_URL + '/' + image.path} />
                            ))}                            
                        </Box>
                    </Stack>
                </OuterPaperStyle>
            </Drawer>

            <SearchFilter />
            
            <GoogleMap
                mapContainerStyle={containerStyle}
                center={position}
                zoom={8}
                options={mapSettings}
            >
                {reports && reports.map((report, index) => (
                    <Marker key={index}
                        position={{
                            lat: Number(report.latitude),
                            lng: Number(report.longitude)
                        }}
                        icon={process.env.REACT_APP_API_URL + '/' + report.crime.icon_3d}
                        onClick={() => { reportDetails(report) }}

                    />
                ))}

            </GoogleMap>
        </>
    )
}

export default ViewReportMap;